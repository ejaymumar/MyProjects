﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary1
{
    public class clsPay
    {
        public static DataClassesDataContext db = null;

        public static void Add(TBL_PAYROLL p)
        {
            db = new DataClassesDataContext();


            db.SP_INSERT_PAYROLL(p.EMP_NO, p.EMP_FNAME, p.EMP_LNAME, p.TRANS_MONTHLYRATE, p.TRANS_PDATE, p.TRANS_BONUS, p.TRANS_OT,
                p.TRANS_SSS, p.TRANS_PH, p.TRANS_TAX, p.TRANS_OTHERS, p.TRANS_ABSENCES, p.TRANS_ADVANCES, p.TRANS_TAD, p.TRANS_TD, p.TRANS_NETPAY);
        }

        public static List<SP_DISPLAY_PAYROLLResult> Display()
        {
            db = new DataClassesDataContext();

            List<SP_DISPLAY_PAYROLLResult> list = db.SP_DISPLAY_PAYROLL().ToList<SP_DISPLAY_PAYROLLResult>();
            return list;
        }


        public static void Delete(TBL_PAYROLL p)
        {
            db = new DataClassesDataContext();

            db.SP_DELETE_PAYROLL(p.TRANS_ID);
        }
    }
}
