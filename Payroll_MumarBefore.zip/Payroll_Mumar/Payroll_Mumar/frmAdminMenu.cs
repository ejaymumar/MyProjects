﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;


namespace Payroll_Mumar
{
    public partial class frmAdminMenu : Form
    {
        public frmAdminMenu()
        {
            InitializeComponent();

            timer1.Start();
        }

        private void buttonX1_Click(object sender, EventArgs e)
        {
            frmSelect s = new frmSelect();

            this.Hide();

            s.Show();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString("M") + "," + DateTime.Today.Year.ToString();
            label2.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }


        private void panel3_MouseClick(object sender, MouseEventArgs e)
        {
            frmAddEmployee a = new frmAddEmployee();

            this.Hide();

            a.Show();
        }

        private void panel4_MouseClick(object sender, MouseEventArgs e)
        {
            frmViewEmp v = new frmViewEmp();

            this.Hide();

            v.Show();
        }

    }
}
