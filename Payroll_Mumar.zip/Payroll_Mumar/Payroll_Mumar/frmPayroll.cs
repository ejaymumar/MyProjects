﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;
using ClassLibrary1;

namespace Payroll_Mumar
{
    public partial class frmPayroll : Office2007Form
    {
        public frmPayroll()
        {
            InitializeComponent();
            txtEmpId.CharacterCasing = CharacterCasing.Upper;

            lblDate.Text = DateTime.Now.ToString("M") + "," + DateTime.Today.Year.ToString();
        }
        TBL_EMPLOYEE tbe = null;
        clsPay cls = new clsPay();
        TBL_PAYROLL pay = new TBL_PAYROLL();

        private void btnSave_Click(object sender, EventArgs e)
        {
            pay.EMP_NO = txtEmpId.Text;
            pay.EMP_FNAME = txtFname.Text;
            pay.EMP_LNAME = txtLname.Text;

            pay.TRANS_MONTHLYRATE = decimal.Parse(txtMRate.Text);
            pay.TRANS_PDATE = DateTime.Parse(lblDate.Text);
            pay.TRANS_BONUS = decimal.Parse(txtBonus.Text);
            pay.TRANS_OT = decimal.Parse(txtOT.Text);
            pay.TRANS_SSS = decimal.Parse(txtSSS.Text);
            pay.TRANS_PH = decimal.Parse(txtPH.Text);
            pay.TRANS_TAX = decimal.Parse(txtTax.Text);
            pay.TRANS_OTHERS = decimal.Parse(txtOthers.Text);
            pay.TRANS_ABSENCES = int.Parse(txtAbsences.Text);
            pay.TRANS_ADVANCES = decimal.Parse(txtAdvances.Text);
            pay.TRANS_TAD = decimal.Parse(txtTAD.Text);
            pay.TRANS_TD = decimal.Parse(txtTD.Text);
            pay.TRANS_NETPAY = decimal.Parse(txtNet.Text);



        }

        private void btnID_Click(object sender, EventArgs e)
        {
            var db = new DataClassesDataContext();


            tbe = db.TBL_EMPLOYEEs.SingleOrDefault(p => p.EMP_NO == txtEmpId.Text);

            if (tbe != null)
            {
                lblID.Text = tbe.EMP_NO;
                txtFname.Text = tbe.EMP_FNAME;
                txtLname.Text = tbe.EMP_LNAME;
                lblRate.Text = tbe.EMP_BASICRATE.ToString();
            }
        }

        private void txtEmpId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                btnID_Click(sender, e);
            }
        }


        

        private void lblRate_TextChanged(object sender, EventArgs e)
        {
            decimal total, rate;
            rate = decimal.Parse(lblRate.Text);


            total = rate * 30;

            txtMRate.Text = total.ToString();
        }

        private void txtAbsences_TextChanged(object sender, EventArgs e)
        {
            //decimal total, rate;
            //int absent;

            //rate = decimal.Parse(lblRate.Text);
            //absent = int.Parse(txtAbsences.Text);

            //total = rate * ;

            //txtMRate.Text = total.ToString();
        }

        private void txtBonus_TextChanged(object sender, EventArgs e)
        {

            decimal net = decimal.Parse(txtMRate.Text);

            if (txtBonus.Text.Length > 0)
            {
                txtNet.Text = (net + decimal.Parse(txtBonus.Text)).ToString();
            }
            else
            {
                txtNet.Text = default(decimal).ToString();
            }

        }

        private void txtOT_TextChanged(object sender, EventArgs e)
        {
            decimal net = decimal.Parse(txtMRate.Text);

            if (txtBonus.Text.Length > 0)
            {
                txtNet.Text = (net + decimal.Parse(txtBonus.Text)).ToString();
            }
            else
            {
                txtNet.Text = default(decimal).ToString();
            }
        }

        private void txtSSS_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPH_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMRate_TextChanged(object sender, EventArgs e)
        {
            txtNet.Text = txtMRate.Text;
        }
    }
}
