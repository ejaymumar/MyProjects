﻿namespace Payroll_Mumar
{
    partial class frmAdminMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAdminMenu));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblWeek = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.lblMonth = new System.Windows.Forms.Label();
            this.lblDay = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnUpdateEmp = new DevComponents.DotNetBar.ButtonX();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnViewEmp = new DevComponents.DotNetBar.ButtonX();
            this.btnClose = new DevComponents.DotNetBar.ButtonX();
            this.btnAddEmp = new DevComponents.DotNetBar.ButtonX();
            this.btnPay = new DevComponents.DotNetBar.ButtonX();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 44.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Lime;
            this.label2.Location = new System.Drawing.Point(14, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 78);
            this.label2.TabIndex = 0;
            this.label2.Text = "Time";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Date";
            this.label1.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(578, 81);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(378, 238);
            this.panel1.TabIndex = 6;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.lblWeek);
            this.panel2.Controls.Add(this.lblYear);
            this.panel2.Controls.Add(this.lblMonth);
            this.panel2.Controls.Add(this.lblDay);
            this.panel2.Location = new System.Drawing.Point(578, 364);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(378, 159);
            this.panel2.TabIndex = 6;
            // 
            // lblWeek
            // 
            this.lblWeek.AutoSize = true;
            this.lblWeek.BackColor = System.Drawing.Color.Transparent;
            this.lblWeek.Font = new System.Drawing.Font("Segoe UI Semibold", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWeek.ForeColor = System.Drawing.Color.Black;
            this.lblWeek.Location = new System.Drawing.Point(233, 80);
            this.lblWeek.Name = "lblWeek";
            this.lblWeek.Size = new System.Drawing.Size(51, 45);
            this.lblWeek.TabIndex = 0;
            this.lblWeek.Text = "W";
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.BackColor = System.Drawing.Color.Transparent;
            this.lblYear.Font = new System.Drawing.Font("Segoe UI Semibold", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYear.ForeColor = System.Drawing.Color.Lime;
            this.lblYear.Location = new System.Drawing.Point(122, 80);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(38, 45);
            this.lblYear.TabIndex = 0;
            this.lblYear.Text = "Y";
            // 
            // lblMonth
            // 
            this.lblMonth.AutoSize = true;
            this.lblMonth.BackColor = System.Drawing.Color.Transparent;
            this.lblMonth.Font = new System.Drawing.Font("Segoe UI Semibold", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMonth.ForeColor = System.Drawing.Color.Lime;
            this.lblMonth.Location = new System.Drawing.Point(121, 27);
            this.lblMonth.Name = "lblMonth";
            this.lblMonth.Size = new System.Drawing.Size(50, 45);
            this.lblMonth.TabIndex = 0;
            this.lblMonth.Text = "M";
            // 
            // lblDay
            // 
            this.lblDay.AutoSize = true;
            this.lblDay.Font = new System.Drawing.Font("Segoe UI", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDay.ForeColor = System.Drawing.Color.Lime;
            this.lblDay.Location = new System.Drawing.Point(-14, 13);
            this.lblDay.Name = "lblDay";
            this.lblDay.Size = new System.Drawing.Size(126, 128);
            this.lblDay.TabIndex = 0;
            this.lblDay.Text = "D";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Impact", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Lime;
            this.label3.Location = new System.Drawing.Point(75, 196);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "Add Employees";
            // 
            // btnUpdateEmp
            // 
            this.btnUpdateEmp.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnUpdateEmp.BackColor = System.Drawing.Color.SpringGreen;
            this.btnUpdateEmp.ColorTable = DevComponents.DotNetBar.eButtonColor.Orange;
            this.btnUpdateEmp.Image = global::Payroll_Mumar.Properties.Resources.appbar_social_stackoverflow;
            this.btnUpdateEmp.Location = new System.Drawing.Point(345, 81);
            this.btnUpdateEmp.Name = "btnUpdateEmp";
            this.btnUpdateEmp.Size = new System.Drawing.Size(143, 106);
            this.btnUpdateEmp.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.btnUpdateEmp.TabIndex = 0;
            this.btnUpdateEmp.TabStop = false;
            this.btnUpdateEmp.Click += new System.EventHandler(this.btnUpdateEmp_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Impact", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Lime;
            this.label4.Location = new System.Drawing.Point(223, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "View Employees";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Impact", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Lime;
            this.label5.Location = new System.Drawing.Point(365, 196);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 17);
            this.label5.TabIndex = 0;
            this.label5.Text = "Update Employees";
            // 
            // btnViewEmp
            // 
            this.btnViewEmp.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnViewEmp.BackColor = System.Drawing.Color.Plum;
            this.btnViewEmp.ColorTable = DevComponents.DotNetBar.eButtonColor.Orange;
            this.btnViewEmp.Image = global::Payroll_Mumar.Properties.Resources.appbar_people_checkbox;
            this.btnViewEmp.Location = new System.Drawing.Point(196, 81);
            this.btnViewEmp.Name = "btnViewEmp";
            this.btnViewEmp.Size = new System.Drawing.Size(143, 106);
            this.btnViewEmp.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.btnViewEmp.TabIndex = 0;
            this.btnViewEmp.TabStop = false;
            this.btnViewEmp.Click += new System.EventHandler(this.btnViewEmp_Click);
            // 
            // btnClose
            // 
            this.btnClose.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.ColorTable = DevComponents.DotNetBar.eButtonColor.Magenta;
            this.btnClose.Image = global::Payroll_Mumar.Properties.Resources.appbar1;
            this.btnClose.Location = new System.Drawing.Point(960, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(52, 50);
            this.btnClose.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.btnClose.TabIndex = 10;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnAddEmp
            // 
            this.btnAddEmp.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnAddEmp.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnAddEmp.ColorTable = DevComponents.DotNetBar.eButtonColor.Orange;
            this.btnAddEmp.Image = global::Payroll_Mumar.Properties.Resources.appbar_group_add;
            this.btnAddEmp.Location = new System.Drawing.Point(47, 81);
            this.btnAddEmp.Name = "btnAddEmp";
            this.btnAddEmp.Size = new System.Drawing.Size(143, 106);
            this.btnAddEmp.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.btnAddEmp.TabIndex = 0;
            this.btnAddEmp.TabStop = false;
            this.btnAddEmp.Click += new System.EventHandler(this.btnAddEmp_Click);
            // 
            // btnPay
            // 
            this.btnPay.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnPay.BackColor = System.Drawing.Color.MediumPurple;
            this.btnPay.ColorTable = DevComponents.DotNetBar.eButtonColor.Orange;
            this.btnPay.Image = global::Payroll_Mumar.Properties.Resources.appbar_group_add;
            this.btnPay.Location = new System.Drawing.Point(47, 259);
            this.btnPay.Name = "btnPay";
            this.btnPay.Size = new System.Drawing.Size(214, 106);
            this.btnPay.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.btnPay.TabIndex = 0;
            this.btnPay.TabStop = false;
            this.btnPay.Click += new System.EventHandler(this.btnAddEmp_Click);
            // 
            // frmAdminMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1038, 778);
            this.ControlBox = false;
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnUpdateEmp);
            this.Controls.Add(this.btnViewEmp);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnPay);
            this.Controls.Add(this.btnAddEmp);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmAdminMenu";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private DevComponents.DotNetBar.ButtonX btnAddEmp;
        private DevComponents.DotNetBar.ButtonX btnViewEmp;
        private DevComponents.DotNetBar.ButtonX btnUpdateEmp;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private DevComponents.DotNetBar.ButtonX btnClose;
        private System.Windows.Forms.Label lblDay;
        private System.Windows.Forms.Label lblMonth;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label lblWeek;
        private DevComponents.DotNetBar.ButtonX btnPay;



    }
}