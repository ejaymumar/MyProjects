﻿namespace Payroll_Mumar
{
    partial class frmAddEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAddEmployee));
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.txtFname = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtLname = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.cmbMname = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.comboItem1 = new DevComponents.Editors.ComboItem();
            this.comboItem2 = new DevComponents.Editors.ComboItem();
            this.comboItem3 = new DevComponents.Editors.ComboItem();
            this.comboItem4 = new DevComponents.Editors.ComboItem();
            this.comboItem5 = new DevComponents.Editors.ComboItem();
            this.comboItem6 = new DevComponents.Editors.ComboItem();
            this.comboItem7 = new DevComponents.Editors.ComboItem();
            this.comboItem8 = new DevComponents.Editors.ComboItem();
            this.comboItem9 = new DevComponents.Editors.ComboItem();
            this.comboItem10 = new DevComponents.Editors.ComboItem();
            this.comboItem11 = new DevComponents.Editors.ComboItem();
            this.comboItem12 = new DevComponents.Editors.ComboItem();
            this.comboItem13 = new DevComponents.Editors.ComboItem();
            this.comboItem14 = new DevComponents.Editors.ComboItem();
            this.comboItem15 = new DevComponents.Editors.ComboItem();
            this.comboItem16 = new DevComponents.Editors.ComboItem();
            this.comboItem17 = new DevComponents.Editors.ComboItem();
            this.comboItem18 = new DevComponents.Editors.ComboItem();
            this.comboItem19 = new DevComponents.Editors.ComboItem();
            this.comboItem20 = new DevComponents.Editors.ComboItem();
            this.comboItem21 = new DevComponents.Editors.ComboItem();
            this.comboItem22 = new DevComponents.Editors.ComboItem();
            this.comboItem23 = new DevComponents.Editors.ComboItem();
            this.comboItem24 = new DevComponents.Editors.ComboItem();
            this.comboItem25 = new DevComponents.Editors.ComboItem();
            this.comboItem26 = new DevComponents.Editors.ComboItem();
            this.cmbGender = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.comboItem27 = new DevComponents.Editors.ComboItem();
            this.comboItem28 = new DevComponents.Editors.ComboItem();
            this.comboItem29 = new DevComponents.Editors.ComboItem();
            this.cmbStatus = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.comboItem30 = new DevComponents.Editors.ComboItem();
            this.comboItem31 = new DevComponents.Editors.ComboItem();
            this.comboItem32 = new DevComponents.Editors.ComboItem();
            this.comboItem33 = new DevComponents.Editors.ComboItem();
            this.comboItem34 = new DevComponents.Editors.ComboItem();
            this.txtAddress = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtDepartment = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtPosition = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.cmbWorkStat = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.comboItem35 = new DevComponents.Editors.ComboItem();
            this.comboItem36 = new DevComponents.Editors.ComboItem();
            this.txtRate = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.dtEmployed = new DevComponents.Editors.DateTimeAdv.DateTimeInput();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.labelX4 = new DevComponents.DotNetBar.LabelX();
            this.labelX5 = new DevComponents.DotNetBar.LabelX();
            this.labelX6 = new DevComponents.DotNetBar.LabelX();
            this.labelX7 = new DevComponents.DotNetBar.LabelX();
            this.labelX8 = new DevComponents.DotNetBar.LabelX();
            this.labelX9 = new DevComponents.DotNetBar.LabelX();
            this.labelX10 = new DevComponents.DotNetBar.LabelX();
            this.labelX11 = new DevComponents.DotNetBar.LabelX();
            this.labelX12 = new DevComponents.DotNetBar.LabelX();
            this.btnUpload = new DevComponents.DotNetBar.ButtonX();
            this.btnSave = new DevComponents.DotNetBar.ButtonX();
            this.picAvatar = new System.Windows.Forms.PictureBox();
            this.btnClear = new DevComponents.DotNetBar.ButtonX();
            ((System.ComponentModel.ISupportInitialize)(this.dtEmployed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar)).BeginInit();
            this.SuspendLayout();
            // 
            // labelX1
            // 
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.Class = "";
            this.labelX1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX1.Location = new System.Drawing.Point(12, 12);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(174, 45);
            this.labelX1.TabIndex = 0;
            this.labelX1.Text = "Emp ID";
            // 
            // txtFname
            // 
            // 
            // 
            // 
            this.txtFname.Border.Class = "TextBoxBorder";
            this.txtFname.Location = new System.Drawing.Point(134, 66);
            this.txtFname.Name = "txtFname";
            this.txtFname.Size = new System.Drawing.Size(194, 22);
            this.txtFname.TabIndex = 1;
            // 
            // txtLname
            // 
            // 
            // 
            // 
            this.txtLname.Border.Class = "TextBoxBorder";
            this.txtLname.Location = new System.Drawing.Point(134, 118);
            this.txtLname.Name = "txtLname";
            this.txtLname.Size = new System.Drawing.Size(194, 22);
            this.txtLname.TabIndex = 3;
            // 
            // cmbMname
            // 
            this.cmbMname.DisplayMember = "Text";
            this.cmbMname.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbMname.FormattingEnabled = true;
            this.cmbMname.ItemHeight = 16;
            this.cmbMname.Items.AddRange(new object[] {
            this.comboItem1,
            this.comboItem2,
            this.comboItem3,
            this.comboItem4,
            this.comboItem5,
            this.comboItem6,
            this.comboItem7,
            this.comboItem8,
            this.comboItem9,
            this.comboItem10,
            this.comboItem11,
            this.comboItem12,
            this.comboItem13,
            this.comboItem14,
            this.comboItem15,
            this.comboItem16,
            this.comboItem17,
            this.comboItem18,
            this.comboItem19,
            this.comboItem20,
            this.comboItem21,
            this.comboItem22,
            this.comboItem23,
            this.comboItem24,
            this.comboItem25,
            this.comboItem26});
            this.cmbMname.Location = new System.Drawing.Point(134, 92);
            this.cmbMname.Name = "cmbMname";
            this.cmbMname.Size = new System.Drawing.Size(59, 22);
            this.cmbMname.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.cmbMname.TabIndex = 2;
            // 
            // comboItem1
            // 
            this.comboItem1.Text = "A.";
            // 
            // comboItem2
            // 
            this.comboItem2.Text = "B.";
            // 
            // comboItem3
            // 
            this.comboItem3.Text = "C.";
            // 
            // comboItem4
            // 
            this.comboItem4.Text = "D.";
            // 
            // comboItem5
            // 
            this.comboItem5.Text = "E.";
            // 
            // comboItem6
            // 
            this.comboItem6.Text = "F.";
            // 
            // comboItem7
            // 
            this.comboItem7.Text = "G.";
            // 
            // comboItem8
            // 
            this.comboItem8.Text = "H.";
            // 
            // comboItem9
            // 
            this.comboItem9.Text = "I.";
            // 
            // comboItem10
            // 
            this.comboItem10.Text = "J.";
            // 
            // comboItem11
            // 
            this.comboItem11.Text = "K.";
            // 
            // comboItem12
            // 
            this.comboItem12.Text = "L.";
            // 
            // comboItem13
            // 
            this.comboItem13.Text = "M.";
            // 
            // comboItem14
            // 
            this.comboItem14.Text = "N.";
            // 
            // comboItem15
            // 
            this.comboItem15.Text = "O.";
            // 
            // comboItem16
            // 
            this.comboItem16.Text = "P.";
            // 
            // comboItem17
            // 
            this.comboItem17.Text = "Q.";
            // 
            // comboItem18
            // 
            this.comboItem18.Text = "R.";
            // 
            // comboItem19
            // 
            this.comboItem19.Text = "S.";
            // 
            // comboItem20
            // 
            this.comboItem20.Text = "T.";
            // 
            // comboItem21
            // 
            this.comboItem21.Text = "U.";
            // 
            // comboItem22
            // 
            this.comboItem22.Text = "V.";
            // 
            // comboItem23
            // 
            this.comboItem23.Text = "W.";
            // 
            // comboItem24
            // 
            this.comboItem24.Text = "X.";
            // 
            // comboItem25
            // 
            this.comboItem25.Text = "Y.";
            // 
            // comboItem26
            // 
            this.comboItem26.Text = "Z.";
            // 
            // cmbGender
            // 
            this.cmbGender.DisplayMember = "Text";
            this.cmbGender.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbGender.FormattingEnabled = true;
            this.cmbGender.ItemHeight = 16;
            this.cmbGender.Items.AddRange(new object[] {
            this.comboItem27,
            this.comboItem28,
            this.comboItem29});
            this.cmbGender.Location = new System.Drawing.Point(134, 144);
            this.cmbGender.Name = "cmbGender";
            this.cmbGender.Size = new System.Drawing.Size(130, 22);
            this.cmbGender.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.cmbGender.TabIndex = 4;
            // 
            // comboItem27
            // 
            this.comboItem27.Text = "Male";
            // 
            // comboItem28
            // 
            this.comboItem28.Text = "Female";
            // 
            // comboItem29
            // 
            this.comboItem29.Text = "Prefer not to";
            // 
            // cmbStatus
            // 
            this.cmbStatus.DisplayMember = "Text";
            this.cmbStatus.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.ItemHeight = 16;
            this.cmbStatus.Items.AddRange(new object[] {
            this.comboItem30,
            this.comboItem31,
            this.comboItem32,
            this.comboItem33,
            this.comboItem34});
            this.cmbStatus.Location = new System.Drawing.Point(134, 170);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(130, 22);
            this.cmbStatus.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.cmbStatus.TabIndex = 5;
            // 
            // comboItem30
            // 
            this.comboItem30.Text = "Single";
            // 
            // comboItem31
            // 
            this.comboItem31.Text = "Married";
            // 
            // comboItem32
            // 
            this.comboItem32.Text = "Divorced";
            // 
            // comboItem33
            // 
            this.comboItem33.Text = "Complicated";
            // 
            // comboItem34
            // 
            this.comboItem34.Text = "Foreveralone";
            // 
            // txtAddress
            // 
            // 
            // 
            // 
            this.txtAddress.Border.Class = "TextBoxBorder";
            this.txtAddress.Location = new System.Drawing.Point(134, 196);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(194, 22);
            this.txtAddress.TabIndex = 6;
            // 
            // txtDepartment
            // 
            // 
            // 
            // 
            this.txtDepartment.Border.Class = "TextBoxBorder";
            this.txtDepartment.Location = new System.Drawing.Point(134, 222);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.Size = new System.Drawing.Size(194, 22);
            this.txtDepartment.TabIndex = 7;
            // 
            // txtPosition
            // 
            // 
            // 
            // 
            this.txtPosition.Border.Class = "TextBoxBorder";
            this.txtPosition.Location = new System.Drawing.Point(134, 248);
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.Size = new System.Drawing.Size(194, 22);
            this.txtPosition.TabIndex = 8;
            // 
            // cmbWorkStat
            // 
            this.cmbWorkStat.DisplayMember = "Text";
            this.cmbWorkStat.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbWorkStat.FormattingEnabled = true;
            this.cmbWorkStat.ItemHeight = 16;
            this.cmbWorkStat.Items.AddRange(new object[] {
            this.comboItem35,
            this.comboItem36});
            this.cmbWorkStat.Location = new System.Drawing.Point(134, 274);
            this.cmbWorkStat.Name = "cmbWorkStat";
            this.cmbWorkStat.Size = new System.Drawing.Size(100, 22);
            this.cmbWorkStat.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.cmbWorkStat.TabIndex = 9;
            // 
            // comboItem35
            // 
            this.comboItem35.Text = "Active";
            // 
            // comboItem36
            // 
            this.comboItem36.Text = "Inactive";
            // 
            // txtRate
            // 
            // 
            // 
            // 
            this.txtRate.Border.Class = "TextBoxBorder";
            this.txtRate.Location = new System.Drawing.Point(134, 300);
            this.txtRate.MaxLength = 5;
            this.txtRate.Name = "txtRate";
            this.txtRate.Size = new System.Drawing.Size(100, 22);
            this.txtRate.TabIndex = 10;
            this.txtRate.Text = "0.00";
            // 
            // dtEmployed
            // 
            // 
            // 
            // 
            this.dtEmployed.BackgroundStyle.Class = "DateTimeInputBackground";
            this.dtEmployed.ButtonDropDown.Shortcut = DevComponents.DotNetBar.eShortcut.AltDown;
            this.dtEmployed.ButtonDropDown.Visible = true;
            this.dtEmployed.Location = new System.Drawing.Point(134, 326);
            // 
            // 
            // 
            this.dtEmployed.MonthCalendar.AnnuallyMarkedDates = new System.DateTime[0];
            // 
            // 
            // 
            this.dtEmployed.MonthCalendar.BackgroundStyle.BackColor = System.Drawing.SystemColors.Window;
            this.dtEmployed.MonthCalendar.BackgroundStyle.Class = "";
            this.dtEmployed.MonthCalendar.ClearButtonVisible = true;
            // 
            // 
            // 
            this.dtEmployed.MonthCalendar.CommandsBackgroundStyle.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground2;
            this.dtEmployed.MonthCalendar.CommandsBackgroundStyle.BackColorGradientAngle = 90;
            this.dtEmployed.MonthCalendar.CommandsBackgroundStyle.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.dtEmployed.MonthCalendar.CommandsBackgroundStyle.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.dtEmployed.MonthCalendar.CommandsBackgroundStyle.BorderTopColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.dtEmployed.MonthCalendar.CommandsBackgroundStyle.BorderTopWidth = 1;
            this.dtEmployed.MonthCalendar.CommandsBackgroundStyle.Class = "";
            this.dtEmployed.MonthCalendar.DisplayMonth = new System.DateTime(2016, 9, 1, 0, 0, 0, 0);
            this.dtEmployed.MonthCalendar.MarkedDates = new System.DateTime[0];
            this.dtEmployed.MonthCalendar.MonthlyMarkedDates = new System.DateTime[0];
            // 
            // 
            // 
            this.dtEmployed.MonthCalendar.NavigationBackgroundStyle.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.dtEmployed.MonthCalendar.NavigationBackgroundStyle.BackColorGradientAngle = 90;
            this.dtEmployed.MonthCalendar.NavigationBackgroundStyle.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.dtEmployed.MonthCalendar.NavigationBackgroundStyle.Class = "";
            this.dtEmployed.MonthCalendar.TodayButtonVisible = true;
            this.dtEmployed.MonthCalendar.WeeklyMarkedDays = new System.DayOfWeek[0];
            this.dtEmployed.Name = "dtEmployed";
            this.dtEmployed.Size = new System.Drawing.Size(194, 22);
            this.dtEmployed.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.dtEmployed.TabIndex = 11;
            // 
            // labelX2
            // 
            this.labelX2.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX2.BackgroundStyle.Class = "";
            this.labelX2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX2.Location = new System.Drawing.Point(36, 63);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(75, 23);
            this.labelX2.TabIndex = 5;
            this.labelX2.Text = "Firstname:";
            // 
            // labelX3
            // 
            this.labelX3.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX3.BackgroundStyle.Class = "";
            this.labelX3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX3.Location = new System.Drawing.Point(36, 89);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(75, 23);
            this.labelX3.TabIndex = 5;
            this.labelX3.Text = "Middle Initial:";
            // 
            // labelX4
            // 
            this.labelX4.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX4.BackgroundStyle.Class = "";
            this.labelX4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX4.Location = new System.Drawing.Point(36, 115);
            this.labelX4.Name = "labelX4";
            this.labelX4.Size = new System.Drawing.Size(75, 23);
            this.labelX4.TabIndex = 5;
            this.labelX4.Text = "Lastname:";
            // 
            // labelX5
            // 
            this.labelX5.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX5.BackgroundStyle.Class = "";
            this.labelX5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX5.Location = new System.Drawing.Point(36, 141);
            this.labelX5.Name = "labelX5";
            this.labelX5.Size = new System.Drawing.Size(75, 23);
            this.labelX5.TabIndex = 5;
            this.labelX5.Text = "Gender:";
            // 
            // labelX6
            // 
            this.labelX6.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX6.BackgroundStyle.Class = "";
            this.labelX6.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX6.Location = new System.Drawing.Point(36, 170);
            this.labelX6.Name = "labelX6";
            this.labelX6.Size = new System.Drawing.Size(75, 23);
            this.labelX6.TabIndex = 5;
            this.labelX6.Text = "Status:";
            // 
            // labelX7
            // 
            this.labelX7.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX7.BackgroundStyle.Class = "";
            this.labelX7.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX7.Location = new System.Drawing.Point(36, 219);
            this.labelX7.Name = "labelX7";
            this.labelX7.Size = new System.Drawing.Size(75, 23);
            this.labelX7.TabIndex = 5;
            this.labelX7.Text = "Department:";
            // 
            // labelX8
            // 
            this.labelX8.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX8.BackgroundStyle.Class = "";
            this.labelX8.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX8.Location = new System.Drawing.Point(36, 193);
            this.labelX8.Name = "labelX8";
            this.labelX8.Size = new System.Drawing.Size(75, 23);
            this.labelX8.TabIndex = 5;
            this.labelX8.Text = "Address:";
            // 
            // labelX9
            // 
            this.labelX9.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX9.BackgroundStyle.Class = "";
            this.labelX9.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX9.Location = new System.Drawing.Point(36, 245);
            this.labelX9.Name = "labelX9";
            this.labelX9.Size = new System.Drawing.Size(75, 23);
            this.labelX9.TabIndex = 5;
            this.labelX9.Text = "Position:";
            // 
            // labelX10
            // 
            this.labelX10.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX10.BackgroundStyle.Class = "";
            this.labelX10.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX10.Location = new System.Drawing.Point(36, 300);
            this.labelX10.Name = "labelX10";
            this.labelX10.Size = new System.Drawing.Size(75, 23);
            this.labelX10.TabIndex = 5;
            this.labelX10.Text = "Basic Rate:";
            // 
            // labelX11
            // 
            this.labelX11.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX11.BackgroundStyle.Class = "";
            this.labelX11.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX11.Location = new System.Drawing.Point(36, 274);
            this.labelX11.Name = "labelX11";
            this.labelX11.Size = new System.Drawing.Size(75, 23);
            this.labelX11.TabIndex = 5;
            this.labelX11.Text = "Work Status:";
            // 
            // labelX12
            // 
            this.labelX12.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX12.BackgroundStyle.Class = "";
            this.labelX12.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX12.Location = new System.Drawing.Point(36, 326);
            this.labelX12.Name = "labelX12";
            this.labelX12.Size = new System.Drawing.Size(92, 23);
            this.labelX12.TabIndex = 5;
            this.labelX12.Text = "Date Employed:";
            // 
            // btnUpload
            // 
            this.btnUpload.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnUpload.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnUpload.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpload.Location = new System.Drawing.Point(444, 260);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(200, 23);
            this.btnUpload.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnUpload.TabIndex = 12;
            this.btnUpload.Text = "Image  Select";
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // btnSave
            // 
            this.btnSave.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnSave.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(444, 300);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(200, 23);
            this.btnSave.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnSave.TabIndex = 13;
            this.btnSave.Text = "Save";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // picAvatar
            // 
            this.picAvatar.Image = global::Payroll_Mumar.Properties.Resources.no_profile;
            this.picAvatar.InitialImage = global::Payroll_Mumar.Properties.Resources.no_profile;
            this.picAvatar.Location = new System.Drawing.Point(444, 63);
            this.picAvatar.Name = "picAvatar";
            this.picAvatar.Size = new System.Drawing.Size(200, 200);
            this.picAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picAvatar.TabIndex = 4;
            this.picAvatar.TabStop = false;
            // 
            // btnClear
            // 
            this.btnClear.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnClear.ColorTable = DevComponents.DotNetBar.eButtonColor.Magenta;
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(444, 329);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(200, 23);
            this.btnClear.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnClear.TabIndex = 14;
            this.btnClear.Text = "Clear";
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // frmAddEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(217)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(699, 395);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnUpload);
            this.Controls.Add(this.picAvatar);
            this.Controls.Add(this.dtEmployed);
            this.Controls.Add(this.cmbStatus);
            this.Controls.Add(this.cmbWorkStat);
            this.Controls.Add(this.cmbGender);
            this.Controls.Add(this.cmbMname);
            this.Controls.Add(this.txtDepartment);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtRate);
            this.Controls.Add(this.txtPosition);
            this.Controls.Add(this.txtLname);
            this.Controls.Add(this.txtFname);
            this.Controls.Add(this.labelX1);
            this.Controls.Add(this.labelX12);
            this.Controls.Add(this.labelX9);
            this.Controls.Add(this.labelX5);
            this.Controls.Add(this.labelX11);
            this.Controls.Add(this.labelX8);
            this.Controls.Add(this.labelX10);
            this.Controls.Add(this.labelX3);
            this.Controls.Add(this.labelX7);
            this.Controls.Add(this.labelX4);
            this.Controls.Add(this.labelX6);
            this.Controls.Add(this.labelX2);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmAddEmployee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employees";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmAddEmployee_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dtEmployed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.Controls.TextBoxX txtFname;
        private DevComponents.DotNetBar.Controls.TextBoxX txtLname;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbMname;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbGender;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbStatus;
        private DevComponents.DotNetBar.Controls.TextBoxX txtAddress;
        private DevComponents.DotNetBar.Controls.TextBoxX txtDepartment;
        private DevComponents.DotNetBar.Controls.TextBoxX txtPosition;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbWorkStat;
        private DevComponents.DotNetBar.Controls.TextBoxX txtRate;
        private DevComponents.Editors.DateTimeAdv.DateTimeInput dtEmployed;
        private System.Windows.Forms.PictureBox picAvatar;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.LabelX labelX3;
        private DevComponents.DotNetBar.LabelX labelX4;
        private DevComponents.DotNetBar.LabelX labelX5;
        private DevComponents.DotNetBar.LabelX labelX6;
        private DevComponents.DotNetBar.LabelX labelX7;
        private DevComponents.DotNetBar.LabelX labelX8;
        private DevComponents.DotNetBar.LabelX labelX9;
        private DevComponents.DotNetBar.LabelX labelX10;
        private DevComponents.DotNetBar.LabelX labelX11;
        private DevComponents.DotNetBar.LabelX labelX12;
        private DevComponents.DotNetBar.ButtonX btnUpload;
        private DevComponents.DotNetBar.ButtonX btnSave;
        private DevComponents.Editors.ComboItem comboItem1;
        private DevComponents.Editors.ComboItem comboItem2;
        private DevComponents.Editors.ComboItem comboItem3;
        private DevComponents.Editors.ComboItem comboItem4;
        private DevComponents.Editors.ComboItem comboItem5;
        private DevComponents.Editors.ComboItem comboItem6;
        private DevComponents.Editors.ComboItem comboItem7;
        private DevComponents.Editors.ComboItem comboItem8;
        private DevComponents.Editors.ComboItem comboItem9;
        private DevComponents.Editors.ComboItem comboItem10;
        private DevComponents.Editors.ComboItem comboItem11;
        private DevComponents.Editors.ComboItem comboItem12;
        private DevComponents.Editors.ComboItem comboItem13;
        private DevComponents.Editors.ComboItem comboItem14;
        private DevComponents.Editors.ComboItem comboItem15;
        private DevComponents.Editors.ComboItem comboItem16;
        private DevComponents.Editors.ComboItem comboItem17;
        private DevComponents.Editors.ComboItem comboItem18;
        private DevComponents.Editors.ComboItem comboItem19;
        private DevComponents.Editors.ComboItem comboItem20;
        private DevComponents.Editors.ComboItem comboItem21;
        private DevComponents.Editors.ComboItem comboItem22;
        private DevComponents.Editors.ComboItem comboItem23;
        private DevComponents.Editors.ComboItem comboItem24;
        private DevComponents.Editors.ComboItem comboItem25;
        private DevComponents.Editors.ComboItem comboItem26;
        private DevComponents.Editors.ComboItem comboItem27;
        private DevComponents.Editors.ComboItem comboItem28;
        private DevComponents.Editors.ComboItem comboItem29;
        private DevComponents.Editors.ComboItem comboItem30;
        private DevComponents.Editors.ComboItem comboItem31;
        private DevComponents.Editors.ComboItem comboItem32;
        private DevComponents.Editors.ComboItem comboItem33;
        private DevComponents.Editors.ComboItem comboItem34;
        private DevComponents.Editors.ComboItem comboItem35;
        private DevComponents.Editors.ComboItem comboItem36;
        private DevComponents.DotNetBar.ButtonX btnClear;
    }
}