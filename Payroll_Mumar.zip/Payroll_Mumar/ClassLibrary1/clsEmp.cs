﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;

namespace ClassLibrary1
{
    public class clsEmp
    {
        public static DataClassesDataContext db = null;

        public static void AddEmp(TBL_EMPLOYEE e)
        {
            db = new DataClassesDataContext();

            db.SP_INSERT_EMP(e.EMP_NO,e.EMP_FNAME, e.EMP_MNAME, e.EMP_LNAME, e.EMP_GENDER, e.EMP_STATUS, e.EMP_ADDRESS, e.EMP_DEPT,
                e.EMP_POSITION, e.EMP_WORKSTAT, e.EMP_BASICRATE, e.EMP_DATEEMPLOYED, e.EMP_PHOTO);
        }

        public static void Update(TBL_EMPLOYEE e)
        {
            db = new DataClassesDataContext();

            db.SP_UPDATE_EMP(e.EMP_NO, e.EMP_FNAME, e.EMP_MNAME, e.EMP_LNAME, e.EMP_GENDER, e.EMP_STATUS, e.EMP_ADDRESS, e.EMP_DEPT,
                e.EMP_POSITION, e.EMP_WORKSTAT, e.EMP_BASICRATE, e.EMP_DATEEMPLOYED, e.EMP_PHOTO);
        }

        public static void Delete(TBL_EMPLOYEE emp)
        {
            db = new DataClassesDataContext();

            db.SP_DELETE_EMP(emp.EMP_ID);
        }


        public static List<SP_DISPLAY_EMPResult> DisplayEmp()
        {
            db = new DataClassesDataContext();

            List<SP_DISPLAY_EMPResult> list = db.SP_DISPLAY_EMP().ToList<SP_DISPLAY_EMPResult>();
            return list;
        }


        
        //public static int CountEmp()
        //{
        //    db = new DataClassesDataContext();

        //    return Convert.ToInt32(db.SP_COUNTEMPID());
        //}


        public static List<SP_SEARCH_EMPResult> SearchEmp(string k)
        {
            db = new DataClassesDataContext();

            List<SP_SEARCH_EMPResult> search = db.SP_SEARCH_EMP(k).ToList<SP_SEARCH_EMPResult>();
            return search;
        }

        public static List<SP_SEARCH_EMPBYNOResult> SearchNo(string no)
        {
            db = new DataClassesDataContext();

            List<SP_SEARCH_EMPBYNOResult> chearch = db.SP_SEARCH_EMPBYNO(no).ToList<SP_SEARCH_EMPBYNOResult>();
            return chearch;
        }

        //AUTO INCREMENT
        //public int CountID()
        //{
        //    db = new DataClassesDataContext();

        //    return db.SP_CNT_ID();
        //}

        public int CountID()
        {
            db = new DataClassesDataContext();


            return Convert.ToInt32(db.SP_CNT_ID());
        }




        public byte[] imageToByte(System.Drawing.Image imageIn)
        {
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);
            return ms.ToArray();
        }

        public Image byteToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            Image returnImage = Image.FromStream(ms);
            return returnImage;
        }
    }
}
