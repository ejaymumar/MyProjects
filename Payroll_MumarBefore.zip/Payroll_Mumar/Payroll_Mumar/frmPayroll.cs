﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;

namespace Payroll_Mumar
{
    public partial class frmPayroll : Office2007Form
    {
        public frmPayroll()
        {
            InitializeComponent();
            lblDate.Text = DateTime.Now.ToString("M") + "," + DateTime.Today.Year.ToString();
        }

        private void frmPayroll_Load(object sender, EventArgs e)
        {

        }
    }
}
