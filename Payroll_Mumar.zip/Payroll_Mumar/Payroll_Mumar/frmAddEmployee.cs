﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;
using System.IO;
using ClassLibrary1;
using System.Data.SqlClient;

namespace Payroll_Mumar
{
    public partial class frmAddEmployee : Office2007Form
    {

        public frmAddEmployee()
        {
            InitializeComponent();
            if (cls.CountID() == 0)
            {
                labelX1.Text = "EMP-" + cls.CountID().ToString().PadLeft(4, '0');
            }
            else
            {
                int no = cls.CountID() + 1;

                labelX1.Text = "EMP-" + no.ToString().PadLeft(4, '0');
            }


            //if (cls.CountID() > 99)
            //{
            //    labelX1.Text = "EMP-" + cls.CountID().ToString().PadLeft(6, '0');
            //}
            //else if (cls.CountID() > 9999)
            //{
            //    labelX1.Text = "EMP-" + cls.CountID().ToString().PadLeft(8, '0');
            //}
            //else if (cls.CountID().ToString() == "EMP-001")
            //{
            //    int no = cls.CountID() + 1;

            //    labelX1.Text = "EMP-" + no.ToString().PadLeft(4, '0');
            //}



        }

        //public static DataClassesDataContext db = null;
        TBL_EMPLOYEE emp = new TBL_EMPLOYEE();
        clsEmp cls = new clsEmp();


        private void btnUpload_Click(object sender, EventArgs e)
        {
            string Location = "";

            OpenFileDialog pic = new OpenFileDialog();
            pic.Filter = "JPG (*.jpg)|*.jpg|GIF (*.gif)|*.gif|PNG (*.png)|*.png";
            pic.Title = "Select Image";
            if (pic.ShowDialog() == DialogResult.OK)
            {
                Location = pic.FileName.ToString();
                picAvatar.ImageLocation = Location;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var db = new DataClassesDataContext();

            emp.EMP_NO = labelX1.Text;
            emp.EMP_FNAME = txtFname.Text;
            emp.EMP_MNAME = cmbMname.Text;
            emp.EMP_LNAME = txtLname.Text;
            emp.EMP_GENDER = cmbGender.Text;
            emp.EMP_STATUS = cmbStatus.Text;
            emp.EMP_ADDRESS = txtAddress.Text;
            emp.EMP_DEPT = txtDepartment.Text;
            emp.EMP_POSITION = txtPosition.Text;
            emp.EMP_WORKSTAT = cmbWorkStat.Text;
            emp.EMP_BASICRATE = decimal.Parse(txtRate.Text);
            emp.EMP_DATEEMPLOYED = DateTime.Parse(dtEmployed.Value.ToString());

            var img = cls.imageToByte(picAvatar.Image);
            emp.EMP_PHOTO = img;

            //NEW//NEW//NEW//NEW//NEW//NEW//NEW//NEW//NEW//NEW
            if (txtFname.Text == "" || cmbMname.Text == "" || txtLname.Text == "" || cmbGender.Text == "" || cmbStatus.Text == "" || txtAddress.Text == "" ||
            txtDepartment.Text == "" || txtPosition.Text == "" || cmbWorkStat.Text == "" || txtRate.Text == "")
            {
                MessageBox.Show("Input Required Fields!");
            }
            else
            {
                clsEmp.AddEmp(emp);

                MessageBox.Show("Successfuly Added Employee!" + "\n" + txtLname.Text + ", " + txtFname.Text);

                Clear();

                if (cls.CountID() == 0)
                {
                    labelX1.Text = "EMP-" + cls.CountID().ToString().PadLeft(4, '0');
                }
                else
                {
                    int no = cls.CountID() + 1;

                    labelX1.Text = "EMP-" + no.ToString().PadLeft(4, '0');
                }
            }
            //NEW//NEW//NEW//NEW//NEW//NEW//NEW//NEW//NEW//NEW//NEW//NEW//NEW//NEW//NEW//NEW//NEW



        }

        public void Clear()
        {
            txtFname.Text = "";
            cmbMname.Text = "";
            txtLname.Text = "";
            cmbGender.Text = "";
            cmbStatus.Text = "";
            txtAddress.Text = "";
            txtDepartment.Text = "";
            txtPosition.Text = "";
            cmbWorkStat.Text = "";
            txtRate.Text = "0.00";
            dtEmployed.Value = DateTime.Today;
            picAvatar.Image = Properties.Resources.no_profile;

            txtFname.Focus();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void frmAddEmployee_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmAdminMenu m = new frmAdminMenu();

            this.Hide();

            m.Show();
        }

        private void txtRate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                btnSave_Click(sender, e);
            }
        }

    }
}
