﻿namespace Payroll_Mumar
{
    partial class frmPayroll
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPayroll));
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.txtLname = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.txtFname = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.labelX4 = new DevComponents.DotNetBar.LabelX();
            this.labelX5 = new DevComponents.DotNetBar.LabelX();
            this.labelX6 = new DevComponents.DotNetBar.LabelX();
            this.labelX7 = new DevComponents.DotNetBar.LabelX();
            this.labelX8 = new DevComponents.DotNetBar.LabelX();
            this.lblDate = new DevComponents.DotNetBar.LabelX();
            this.labelX10 = new DevComponents.DotNetBar.LabelX();
            this.labelX11 = new DevComponents.DotNetBar.LabelX();
            this.txtEmpId = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX12 = new DevComponents.DotNetBar.LabelX();
            this.labelX13 = new DevComponents.DotNetBar.LabelX();
            this.labelX14 = new DevComponents.DotNetBar.LabelX();
            this.labelX15 = new DevComponents.DotNetBar.LabelX();
            this.txtMRate = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtBonus = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtOT = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtSSS = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtPH = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtTax = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtAbsences = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtOthers = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtAdvances = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtTAD = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtNet = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.btnID = new System.Windows.Forms.Button();
            this.ipAddressInput1 = new DevComponents.Editors.IpAddressInput();
            this.btnSave = new DevComponents.DotNetBar.ButtonX();
            this.labelX9 = new DevComponents.DotNetBar.LabelX();
            this.txtTD = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.lblRate = new DevComponents.DotNetBar.LabelX();
            this.labelX16 = new DevComponents.DotNetBar.LabelX();
            this.txtAbsentT = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.lblID = new DevComponents.DotNetBar.LabelX();
            ((System.ComponentModel.ISupportInitialize)(this.ipAddressInput1)).BeginInit();
            this.SuspendLayout();
            // 
            // labelX1
            // 
            this.labelX1.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.Class = "";
            this.labelX1.Location = new System.Drawing.Point(29, 88);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(75, 23);
            this.labelX1.TabIndex = 0;
            this.labelX1.Text = "Lastname:";
            // 
            // txtLname
            // 
            // 
            // 
            // 
            this.txtLname.Border.Class = "";
            this.txtLname.Enabled = false;
            this.txtLname.Location = new System.Drawing.Point(110, 91);
            this.txtLname.Name = "txtLname";
            this.txtLname.Size = new System.Drawing.Size(100, 20);
            this.txtLname.TabIndex = 1;
            // 
            // labelX2
            // 
            this.labelX2.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX2.BackgroundStyle.Class = "";
            this.labelX2.Location = new System.Drawing.Point(216, 88);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(75, 23);
            this.labelX2.TabIndex = 0;
            this.labelX2.Text = "Firstname:";
            // 
            // txtFname
            // 
            // 
            // 
            // 
            this.txtFname.Border.Class = "";
            this.txtFname.Enabled = false;
            this.txtFname.Location = new System.Drawing.Point(297, 91);
            this.txtFname.Name = "txtFname";
            this.txtFname.Size = new System.Drawing.Size(100, 20);
            this.txtFname.TabIndex = 1;
            // 
            // labelX3
            // 
            // 
            // 
            // 
            this.labelX3.BackgroundStyle.Class = "";
            this.labelX3.Location = new System.Drawing.Point(266, 200);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(75, 23);
            this.labelX3.TabIndex = 2;
            this.labelX3.Text = "Others";
            // 
            // labelX4
            // 
            // 
            // 
            // 
            this.labelX4.BackgroundStyle.Class = "";
            this.labelX4.Location = new System.Drawing.Point(266, 171);
            this.labelX4.Name = "labelX4";
            this.labelX4.Size = new System.Drawing.Size(75, 23);
            this.labelX4.TabIndex = 2;
            this.labelX4.Text = "Taxes:";
            // 
            // labelX5
            // 
            // 
            // 
            // 
            this.labelX5.BackgroundStyle.Class = "";
            this.labelX5.Location = new System.Drawing.Point(29, 287);
            this.labelX5.Name = "labelX5";
            this.labelX5.Size = new System.Drawing.Size(75, 23);
            this.labelX5.TabIndex = 2;
            this.labelX5.Text = "PhilHealth:";
            // 
            // labelX6
            // 
            // 
            // 
            // 
            this.labelX6.BackgroundStyle.Class = "";
            this.labelX6.Location = new System.Drawing.Point(29, 258);
            this.labelX6.Name = "labelX6";
            this.labelX6.Size = new System.Drawing.Size(75, 23);
            this.labelX6.TabIndex = 2;
            this.labelX6.Text = "SSS:";
            // 
            // labelX7
            // 
            // 
            // 
            // 
            this.labelX7.BackgroundStyle.Class = "";
            this.labelX7.Location = new System.Drawing.Point(29, 229);
            this.labelX7.Name = "labelX7";
            this.labelX7.Size = new System.Drawing.Size(75, 23);
            this.labelX7.TabIndex = 2;
            this.labelX7.Text = "Overtime:";
            // 
            // labelX8
            // 
            // 
            // 
            // 
            this.labelX8.BackgroundStyle.Class = "";
            this.labelX8.Location = new System.Drawing.Point(29, 200);
            this.labelX8.Name = "labelX8";
            this.labelX8.Size = new System.Drawing.Size(75, 23);
            this.labelX8.TabIndex = 2;
            this.labelX8.Text = "Bonus:";
            // 
            // lblDate
            // 
            // 
            // 
            // 
            this.lblDate.BackgroundStyle.Class = "";
            this.lblDate.Location = new System.Drawing.Point(347, 12);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(152, 23);
            this.lblDate.TabIndex = 2;
            this.lblDate.Text = "Date:";
            // 
            // labelX10
            // 
            // 
            // 
            // 
            this.labelX10.BackgroundStyle.Class = "";
            this.labelX10.Location = new System.Drawing.Point(29, 171);
            this.labelX10.Name = "labelX10";
            this.labelX10.Size = new System.Drawing.Size(75, 23);
            this.labelX10.TabIndex = 2;
            this.labelX10.Text = "Monthly Rate:";
            // 
            // labelX11
            // 
            this.labelX11.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX11.BackgroundStyle.Class = "";
            this.labelX11.Location = new System.Drawing.Point(29, 59);
            this.labelX11.Name = "labelX11";
            this.labelX11.Size = new System.Drawing.Size(75, 23);
            this.labelX11.TabIndex = 0;
            this.labelX11.Text = "Employee No:";
            // 
            // txtEmpId
            // 
            // 
            // 
            // 
            this.txtEmpId.Border.Class = "";
            this.txtEmpId.Location = new System.Drawing.Point(110, 62);
            this.txtEmpId.Name = "txtEmpId";
            this.txtEmpId.Size = new System.Drawing.Size(287, 20);
            this.txtEmpId.TabIndex = 1;
            this.txtEmpId.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEmpId_KeyPress);
            // 
            // labelX12
            // 
            // 
            // 
            // 
            this.labelX12.BackgroundStyle.Class = "";
            this.labelX12.Location = new System.Drawing.Point(29, 399);
            this.labelX12.Name = "labelX12";
            this.labelX12.Size = new System.Drawing.Size(75, 23);
            this.labelX12.TabIndex = 2;
            this.labelX12.Text = "Net Pay:";
            // 
            // labelX13
            // 
            // 
            // 
            // 
            this.labelX13.BackgroundStyle.Class = "";
            this.labelX13.Location = new System.Drawing.Point(266, 287);
            this.labelX13.Name = "labelX13";
            this.labelX13.Size = new System.Drawing.Size(75, 23);
            this.labelX13.TabIndex = 2;
            this.labelX13.Text = "TAD:";
            // 
            // labelX14
            // 
            // 
            // 
            // 
            this.labelX14.BackgroundStyle.Class = "";
            this.labelX14.Location = new System.Drawing.Point(266, 258);
            this.labelX14.Name = "labelX14";
            this.labelX14.Size = new System.Drawing.Size(75, 23);
            this.labelX14.TabIndex = 2;
            this.labelX14.Text = "Advances:";
            // 
            // labelX15
            // 
            // 
            // 
            // 
            this.labelX15.BackgroundStyle.Class = "";
            this.labelX15.Location = new System.Drawing.Point(29, 316);
            this.labelX15.Name = "labelX15";
            this.labelX15.Size = new System.Drawing.Size(75, 23);
            this.labelX15.TabIndex = 2;
            this.labelX15.Text = "Days Absent:";
            // 
            // txtMRate
            // 
            // 
            // 
            // 
            this.txtMRate.Border.Class = "TextBoxBorder";
            this.txtMRate.Enabled = false;
            this.txtMRate.Location = new System.Drawing.Point(110, 174);
            this.txtMRate.Name = "txtMRate";
            this.txtMRate.Size = new System.Drawing.Size(123, 20);
            this.txtMRate.TabIndex = 2;
            this.txtMRate.Text = "0";
            this.txtMRate.TextChanged += new System.EventHandler(this.txtMRate_TextChanged);
            // 
            // txtBonus
            // 
            // 
            // 
            // 
            this.txtBonus.Border.Class = "TextBoxBorder";
            this.txtBonus.Location = new System.Drawing.Point(110, 203);
            this.txtBonus.Name = "txtBonus";
            this.txtBonus.Size = new System.Drawing.Size(123, 20);
            this.txtBonus.TabIndex = 3;
            this.txtBonus.Text = "0";
            this.txtBonus.TextChanged += new System.EventHandler(this.txtBonus_TextChanged);
            // 
            // txtOT
            // 
            // 
            // 
            // 
            this.txtOT.Border.Class = "TextBoxBorder";
            this.txtOT.Location = new System.Drawing.Point(110, 232);
            this.txtOT.Name = "txtOT";
            this.txtOT.Size = new System.Drawing.Size(123, 20);
            this.txtOT.TabIndex = 4;
            this.txtOT.Text = "0";
            this.txtOT.TextChanged += new System.EventHandler(this.txtOT_TextChanged);
            // 
            // txtSSS
            // 
            // 
            // 
            // 
            this.txtSSS.Border.Class = "TextBoxBorder";
            this.txtSSS.Location = new System.Drawing.Point(110, 261);
            this.txtSSS.Name = "txtSSS";
            this.txtSSS.Size = new System.Drawing.Size(123, 20);
            this.txtSSS.TabIndex = 5;
            this.txtSSS.Text = "0";
            this.txtSSS.TextChanged += new System.EventHandler(this.txtSSS_TextChanged);
            // 
            // txtPH
            // 
            // 
            // 
            // 
            this.txtPH.Border.Class = "TextBoxBorder";
            this.txtPH.Location = new System.Drawing.Point(110, 290);
            this.txtPH.Name = "txtPH";
            this.txtPH.Size = new System.Drawing.Size(123, 20);
            this.txtPH.TabIndex = 6;
            this.txtPH.Text = "0";
            this.txtPH.TextChanged += new System.EventHandler(this.txtPH_TextChanged);
            // 
            // txtTax
            // 
            // 
            // 
            // 
            this.txtTax.Border.Class = "TextBoxBorder";
            this.txtTax.Location = new System.Drawing.Point(347, 174);
            this.txtTax.Name = "txtTax";
            this.txtTax.Size = new System.Drawing.Size(123, 20);
            this.txtTax.TabIndex = 7;
            this.txtTax.Text = "0";
            // 
            // txtAbsences
            // 
            // 
            // 
            // 
            this.txtAbsences.Border.Class = "TextBoxBorder";
            this.txtAbsences.Location = new System.Drawing.Point(110, 319);
            this.txtAbsences.Name = "txtAbsences";
            this.txtAbsences.Size = new System.Drawing.Size(123, 20);
            this.txtAbsences.TabIndex = 9;
            this.txtAbsences.Text = "0";
            this.txtAbsences.TextChanged += new System.EventHandler(this.txtAbsences_TextChanged);
            // 
            // txtOthers
            // 
            // 
            // 
            // 
            this.txtOthers.Border.Class = "TextBoxBorder";
            this.txtOthers.Location = new System.Drawing.Point(347, 203);
            this.txtOthers.Name = "txtOthers";
            this.txtOthers.Size = new System.Drawing.Size(123, 20);
            this.txtOthers.TabIndex = 8;
            this.txtOthers.Text = "0";
            // 
            // txtAdvances
            // 
            // 
            // 
            // 
            this.txtAdvances.Border.Class = "TextBoxBorder";
            this.txtAdvances.Location = new System.Drawing.Point(347, 261);
            this.txtAdvances.Name = "txtAdvances";
            this.txtAdvances.Size = new System.Drawing.Size(123, 20);
            this.txtAdvances.TabIndex = 10;
            this.txtAdvances.Text = "0";
            // 
            // txtTAD
            // 
            // 
            // 
            // 
            this.txtTAD.Border.Class = "TextBoxBorder";
            this.txtTAD.Location = new System.Drawing.Point(347, 290);
            this.txtTAD.Name = "txtTAD";
            this.txtTAD.Size = new System.Drawing.Size(123, 20);
            this.txtTAD.TabIndex = 11;
            this.txtTAD.Text = "0";
            // 
            // txtNet
            // 
            // 
            // 
            // 
            this.txtNet.Border.Class = "TextBoxBorder";
            this.txtNet.Enabled = false;
            this.txtNet.Location = new System.Drawing.Point(131, 402);
            this.txtNet.Name = "txtNet";
            this.txtNet.Size = new System.Drawing.Size(231, 20);
            this.txtNet.TabIndex = 3;
            this.txtNet.Text = "0";
            // 
            // btnID
            // 
            this.btnID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnID.Location = new System.Drawing.Point(484, 79);
            this.btnID.Name = "btnID";
            this.btnID.Size = new System.Drawing.Size(75, 23);
            this.btnID.TabIndex = 12;
            this.btnID.Text = "ID";
            this.btnID.UseVisualStyleBackColor = true;
            this.btnID.Visible = false;
            this.btnID.Click += new System.EventHandler(this.btnID_Click);
            // 
            // ipAddressInput1
            // 
            this.ipAddressInput1.AutoOverwrite = true;
            // 
            // 
            // 
            this.ipAddressInput1.BackgroundStyle.Class = "DateTimeInputBackground";
            this.ipAddressInput1.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.ipAddressInput1.ButtonFreeText.Visible = true;
            this.ipAddressInput1.Location = new System.Drawing.Point(0, 479);
            this.ipAddressInput1.Name = "ipAddressInput1";
            this.ipAddressInput1.Size = new System.Drawing.Size(162, 20);
            this.ipAddressInput1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ipAddressInput1.TabIndex = 13;
            // 
            // btnSave
            // 
            this.btnSave.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnSave.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnSave.Location = new System.Drawing.Point(236, 428);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnSave.TabIndex = 14;
            this.btnSave.Text = "Save";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // labelX9
            // 
            // 
            // 
            // 
            this.labelX9.BackgroundStyle.Class = "";
            this.labelX9.Location = new System.Drawing.Point(29, 370);
            this.labelX9.Name = "labelX9";
            this.labelX9.Size = new System.Drawing.Size(96, 23);
            this.labelX9.TabIndex = 2;
            this.labelX9.Text = "Total Deductions:";
            // 
            // txtTD
            // 
            // 
            // 
            // 
            this.txtTD.Border.Class = "TextBoxBorder";
            this.txtTD.Enabled = false;
            this.txtTD.Location = new System.Drawing.Point(131, 376);
            this.txtTD.Name = "txtTD";
            this.txtTD.Size = new System.Drawing.Size(123, 20);
            this.txtTD.TabIndex = 11;
            this.txtTD.Text = "0";
            // 
            // lblRate
            // 
            this.lblRate.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.lblRate.BackgroundStyle.Class = "";
            this.lblRate.Location = new System.Drawing.Point(403, 88);
            this.lblRate.Name = "lblRate";
            this.lblRate.Size = new System.Drawing.Size(75, 23);
            this.lblRate.TabIndex = 0;
            this.lblRate.Text = "0";
            this.lblRate.TextChanged += new System.EventHandler(this.lblRate_TextChanged);
            // 
            // labelX16
            // 
            // 
            // 
            // 
            this.labelX16.BackgroundStyle.Class = "";
            this.labelX16.Location = new System.Drawing.Point(266, 229);
            this.labelX16.Name = "labelX16";
            this.labelX16.Size = new System.Drawing.Size(75, 23);
            this.labelX16.TabIndex = 2;
            this.labelX16.Text = "Total Absent:";
            // 
            // txtAbsentT
            // 
            // 
            // 
            // 
            this.txtAbsentT.Border.Class = "TextBoxBorder";
            this.txtAbsentT.Location = new System.Drawing.Point(347, 232);
            this.txtAbsentT.Name = "txtAbsentT";
            this.txtAbsentT.Size = new System.Drawing.Size(123, 20);
            this.txtAbsentT.TabIndex = 9;
            this.txtAbsentT.Text = "0";
            // 
            // lblID
            // 
            this.lblID.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.lblID.BackgroundStyle.Class = "";
            this.lblID.Location = new System.Drawing.Point(29, 30);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(75, 23);
            this.lblID.TabIndex = 0;
            this.lblID.Text = "Employee ID";
            this.lblID.Visible = false;
            // 
            // frmPayroll
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(217)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(511, 476);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.ipAddressInput1);
            this.Controls.Add(this.btnID);
            this.Controls.Add(this.txtTD);
            this.Controls.Add(this.txtTAD);
            this.Controls.Add(this.txtAdvances);
            this.Controls.Add(this.txtNet);
            this.Controls.Add(this.txtPH);
            this.Controls.Add(this.txtOthers);
            this.Controls.Add(this.txtOT);
            this.Controls.Add(this.txtAbsentT);
            this.Controls.Add(this.txtAbsences);
            this.Controls.Add(this.txtSSS);
            this.Controls.Add(this.txtTax);
            this.Controls.Add(this.txtBonus);
            this.Controls.Add(this.txtMRate);
            this.Controls.Add(this.labelX10);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.labelX16);
            this.Controls.Add(this.labelX15);
            this.Controls.Add(this.labelX6);
            this.Controls.Add(this.labelX14);
            this.Controls.Add(this.labelX8);
            this.Controls.Add(this.labelX5);
            this.Controls.Add(this.labelX9);
            this.Controls.Add(this.labelX13);
            this.Controls.Add(this.labelX7);
            this.Controls.Add(this.labelX12);
            this.Controls.Add(this.labelX4);
            this.Controls.Add(this.labelX3);
            this.Controls.Add(this.txtFname);
            this.Controls.Add(this.labelX2);
            this.Controls.Add(this.txtEmpId);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.labelX11);
            this.Controls.Add(this.txtLname);
            this.Controls.Add(this.lblRate);
            this.Controls.Add(this.labelX1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmPayroll";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "0";
            ((System.ComponentModel.ISupportInitialize)(this.ipAddressInput1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.Controls.TextBoxX txtLname;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.Controls.TextBoxX txtFname;
        private DevComponents.DotNetBar.LabelX labelX3;
        private DevComponents.DotNetBar.LabelX labelX4;
        private DevComponents.DotNetBar.LabelX labelX5;
        private DevComponents.DotNetBar.LabelX labelX6;
        private DevComponents.DotNetBar.LabelX labelX7;
        private DevComponents.DotNetBar.LabelX labelX8;
        private DevComponents.DotNetBar.LabelX lblDate;
        private DevComponents.DotNetBar.LabelX labelX10;
        private DevComponents.DotNetBar.LabelX labelX11;
        private DevComponents.DotNetBar.Controls.TextBoxX txtEmpId;
        private DevComponents.DotNetBar.LabelX labelX12;
        private DevComponents.DotNetBar.LabelX labelX13;
        private DevComponents.DotNetBar.LabelX labelX14;
        private DevComponents.DotNetBar.LabelX labelX15;
        private DevComponents.DotNetBar.Controls.TextBoxX txtMRate;
        private DevComponents.DotNetBar.Controls.TextBoxX txtBonus;
        private DevComponents.DotNetBar.Controls.TextBoxX txtOT;
        private DevComponents.DotNetBar.Controls.TextBoxX txtSSS;
        private DevComponents.DotNetBar.Controls.TextBoxX txtPH;
        private DevComponents.DotNetBar.Controls.TextBoxX txtTax;
        private DevComponents.DotNetBar.Controls.TextBoxX txtAbsences;
        private DevComponents.DotNetBar.Controls.TextBoxX txtOthers;
        private DevComponents.DotNetBar.Controls.TextBoxX txtAdvances;
        private DevComponents.DotNetBar.Controls.TextBoxX txtTAD;
        private DevComponents.DotNetBar.Controls.TextBoxX txtNet;
        private System.Windows.Forms.Button btnID;
        private DevComponents.Editors.IpAddressInput ipAddressInput1;
        private DevComponents.DotNetBar.ButtonX btnSave;
        private DevComponents.DotNetBar.LabelX labelX9;
        private DevComponents.DotNetBar.Controls.TextBoxX txtTD;
        private DevComponents.DotNetBar.LabelX lblRate;
        private DevComponents.DotNetBar.LabelX labelX16;
        private DevComponents.DotNetBar.Controls.TextBoxX txtAbsentT;
        private DevComponents.DotNetBar.LabelX lblID;
    }
}