﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;

namespace Payroll_Mumar
{
    public partial class frmAdminMenu : Form
    {
        public frmAdminMenu()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            timer1.Start();
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            //label1.Text = DateTime.Now.ToString("M") + ", " + DateTime.Today.Year.ToString();

            lblDay.Text = DateTime.Now.ToString("dd");
            lblMonth.Text = DateTime.Now.ToString("MMM");
            lblYear.Text = DateTime.Now.Year.ToString();
            lblWeek.Text = DateTime.Now.DayOfWeek.ToString();
            
            label2.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            frmSelect s = new frmSelect();

            this.Hide();
            s.Show();
        }

        private void btnAddEmp_Click(object sender, EventArgs e)
        {
            frmAddEmployee a = new frmAddEmployee();

            this.Hide();
            a.Show();
        }

        private void btnViewEmp_Click(object sender, EventArgs e)
        {
            frmViewEmp v = new frmViewEmp();

            this.Hide();
            v.Show();
        }

        private void btnUpdateEmp_Click(object sender, EventArgs e)
        {
            frmEmpUpdate u = new frmEmpUpdate();

            this.Hide();
            u.Show();
        }



    }
}
