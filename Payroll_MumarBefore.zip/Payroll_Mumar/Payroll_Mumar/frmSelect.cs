﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;

namespace Payroll_Mumar
{
    public partial class frmSelect : Office2007Form
    {
        public frmSelect()
        {
            InitializeComponent();
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            frmAdminLog al = new frmAdminLog();

            this.Hide();

            al.Show();
        }

        private void btnEmployee_Click(object sender, EventArgs e)
        {
            frmEmpMenu emp = new frmEmpMenu();

            this.Hide();

            emp.Show();
        }

        private void frmSelect_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Dispose();
            this.Close();
            Application.Exit();
        }
    }
}
