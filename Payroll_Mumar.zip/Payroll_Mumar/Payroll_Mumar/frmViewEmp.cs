﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;
using ClassLibrary1;

namespace Payroll_Mumar
{
    public partial class frmViewEmp : Office2007Form
    {
        public frmViewEmp()
        {
            InitializeComponent();
            dataGridViewX1.DataSource = clsEmp.DisplayEmp();
        }
        TBL_EMPLOYEE emp = new TBL_EMPLOYEE();

        private void textBoxX1_TextChanged(object sender, EventArgs e)
        {
            dataGridViewX1.DataSource = clsEmp.SearchEmp(textBoxX1.Text);
        }

        private void frmViewEmp_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmAdminMenu m = new frmAdminMenu();

            this.Hide();

            m.Show();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            emp.EMP_ID = int.Parse(dataGridViewX1.CurrentRow.Cells[0].Value.ToString());

            clsEmp.Delete(emp);
            dataGridViewX1.DataSource = clsEmp.DisplayEmp();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CrystalReport1 report = new CrystalReport1();
            report.SetDataSource(dataGridViewX1.DataSource);

            frmReportEmp emp = new frmReportEmp();
            emp.crystalReportViewer1.ReportSource = report;
            emp.Show();
        }
    }
}
