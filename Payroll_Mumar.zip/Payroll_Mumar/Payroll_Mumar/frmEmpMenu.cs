﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;
using System.Text.RegularExpressions;
using ClassLibrary1;

namespace Payroll_Mumar
{
    public partial class frmEmpMenu : Office2007Form
    {
        public frmEmpMenu()
        {
            InitializeComponent();

            timer1.Start();


            txtEmpID.CharacterCasing = CharacterCasing.Upper;
            txtName.CharacterCasing = CharacterCasing.Upper;
            txtDepartment.CharacterCasing = CharacterCasing.Upper;
            txtPosition.CharacterCasing = CharacterCasing.Upper;


            buttonX1.Visible = false;
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            labelX1.Text = DateTime.Now.ToString("M") + ", " + DateTime.Today.Year.ToString();
            labelX2.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }

        private void txtEmpID_TextChanged(object sender, EventArgs e)
        {

            Regex r = new Regex("[^0-9]");
            Match m = r.Match(txtEmpID.Text);

        }

        private void buttonX1_Click(object sender, EventArgs e)
        {
            clsEmp cls = new clsEmp();

            var db = new DataClassesDataContext();

            TBL_EMPLOYEE tbe = null;

            tbe = db.TBL_EMPLOYEEs.SingleOrDefault(p => p.EMP_NO == txtEmpID.Text);

            if (tbe != null)
            {
                MessageBox.Show("Welcome " + tbe.EMP_LNAME);
                txtName.Text = tbe.EMP_FNAME + " " + tbe.EMP_MNAME + " " + tbe.EMP_LNAME;
                txtDepartment.Text = tbe.EMP_DEPT;
                txtPosition.Text = tbe.EMP_POSITION;

                pictureBox1.Image = cls.byteToImage(tbe.EMP_PHOTO.ToArray());
            }


        }

        private void txtEmpID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                buttonX1_Click(sender, e);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            frmSelect s = new frmSelect();

            this.Hide();

            s.Show();
        }
    }
}
