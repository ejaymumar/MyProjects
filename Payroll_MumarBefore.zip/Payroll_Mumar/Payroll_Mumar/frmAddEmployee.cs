﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;
using System.IO;
using ClassLibrary1;
using System.Data.SqlClient;

namespace Payroll_Mumar
{
    public partial class frmAddEmployee : Office2007Form
    {
        
        public frmAddEmployee()
        {
            InitializeComponent();


            int no = clsEmp.CountEmp() + 1;
            labelX1.Text = "EMP-" + no.ToString().PadLeft(3, '0');
        }

        //public static DataClassesDataContext db = null;

        TBL_EMPLOYEE emp = new TBL_EMPLOYEE();
        clsEmp cls = new clsEmp();


        private void btnUpload_Click(object sender, EventArgs e)
        {
            string Location = "";

            OpenFileDialog pic = new OpenFileDialog();
            pic.Filter = "JPG (*.jpg)|*.jpg|GIF (*.gif)|*.gif|PNG (*.png)|*.png";
            pic.Title = "Select Image";
            if (pic.ShowDialog() == DialogResult.OK)
            {
                Location = pic.FileName.ToString();
                picAvatar.ImageLocation = Location;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            emp.EMP_ID = labelX1.Text;
            emp.EMP_FNAME = txtFname.Text;
            emp.EMP_MNAME = cmbMname.Text;
            emp.EMP_LNAME = txtLname.Text;
            emp.EMP_GENDER = cmbGender.Text;
            emp.EMP_STATUS = cmbStatus.Text;
            emp.EMP_ADDRESS = txtAddress.Text;
            emp.EMP_DEPT = txtDepartment.Text;
            emp.EMP_POSITION = txtPosition.Text;
            emp.EMP_WORKSTAT = cmbWorkStat.Text;
            emp.EMP_BASICRATE = decimal.Parse(txtRate.Text);
            emp.EMP_DATEEMPLOYED = DateTime.Parse(dtEmployed.Value.ToString());

            var img = cls.imageToByte(picAvatar.Image);
            emp.EMP_PHOTO = img;

            

            //para ma retrieve ang ikaduha maoy gamita

            //t = new tblemp;
            //class1  cls = new class1();

            //be sure nga ing anion nimo siya
            //  var db = new DataClasses1DataContext();
            //  t = db.tbl_Emps.SingleOrDefault(p => p.emp_id == validID);
            //  if (t != null)
            //                {
            //picturebox1.image = cls.byteArrayToImage(t.emp_photo.ToArray());


            clsEmp.AddEmp(emp);

            MessageBox.Show("Successfuly Added Employee!" + "\n" + txtLname.Text + ", " + txtFname.Text);
            Clear();

            int no = clsEmp.CountEmp() + 1;
            labelX1.Text = "EMP-" + no.ToString().PadLeft(3, '0');
        }

        public void Clear()
        {
            txtFname.Text = "";
            cmbMname.Text = "";
            txtLname.Text = "";
            cmbGender.Text = "";
            cmbStatus.Text = "";
            txtAddress.Text = "";
            txtDepartment.Text = "";
            txtPosition.Text = "";
            cmbWorkStat.Text = "";
            txtRate.Text = "";
            dtEmployed.Value = DateTime.Today;
            picAvatar.Image = Properties.Resources.no_profile;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void frmAddEmployee_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmAdminMenu m = new frmAdminMenu();

            this.Hide();

            m.Show();
        }

    }
}
