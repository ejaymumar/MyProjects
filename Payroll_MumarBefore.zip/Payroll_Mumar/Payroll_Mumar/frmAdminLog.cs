﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Payroll_Mumar
{
    public partial class frmAdminLog : Form
    {
        public frmAdminLog()
        {
            InitializeComponent();
        }

        private void frmAdminLog_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmSelect s = new frmSelect();

            this.Hide();

            s.Show();
        }

        private void btnLog_Click(object sender, EventArgs e)
        {
            if (txtUser.Text == "admin" && txtPass.Text == "123")
            {
                frmAdminMenu am = new frmAdminMenu();

                this.Hide();

                am.Show();
            }
            else
            {
                MessageBox.Show("Invalid Account!");
            }

        }
    }
}
