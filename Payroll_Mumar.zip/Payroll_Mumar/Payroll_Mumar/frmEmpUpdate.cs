﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;
using System.Text.RegularExpressions;
using ClassLibrary1;

namespace Payroll_Mumar
{
    public partial class frmEmpUpdate : Office2007Form
    {
        public frmEmpUpdate()
        {
            InitializeComponent();
            txtID.CharacterCasing = CharacterCasing.Upper;

            btnUpdate.Enabled = false;
            btnUpload.Enabled = false;
        }
        clsEmp cls = new clsEmp();

        private void btnVerify_Click(object sender, EventArgs e)
        {
            clsEmp cls = new clsEmp();
            var db = new DataClassesDataContext();

            TBL_EMPLOYEE tbe = null;

            tbe = db.TBL_EMPLOYEEs.SingleOrDefault(p => p.EMP_NO == txtID.Text);

            if (tbe != null)
            {
                txtID.Text = tbe.EMP_NO;
                txtFname.Text = tbe.EMP_FNAME;
                cmbMname.Text = tbe.EMP_MNAME;
                txtLname.Text = tbe.EMP_LNAME;
                cmbGender.Text = tbe.EMP_GENDER;
                cmbStatus.Text = tbe.EMP_STATUS;
                txtAddress.Text = tbe.EMP_ADDRESS;
                txtDepartment.Text = tbe.EMP_DEPT;
                txtPosition.Text = tbe.EMP_POSITION;
                cmbWorkStat.Text = tbe.EMP_WORKSTAT;
                txtRate.Text = tbe.EMP_BASICRATE.ToString();
                dtEmployed.Value = tbe.EMP_DATEEMPLOYED;
                picAvatar.Image = cls.byteToImage(tbe.EMP_PHOTO.ToArray());

                dgNo.DataSource = clsEmp.SearchNo(txtID.Text);
                txtID.Enabled = false;
                btnUpdate.Enabled = true;
                btnUpload.Enabled = true;
                timer1.Stop();
            }
            else
            {
                MessageBox.Show("No!");
            }

        }

        private void txtID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                btnVerify_Click(sender, e);
            }
        }
        //NEWNEWNEWNEWNEWNWENWENWENWEWNEWewewe//NEWNEWNEWNEWNEWNWENWENWENWEWNEWewewe
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            TBL_EMPLOYEE emp = new TBL_EMPLOYEE();

            emp.EMP_NO = txtID.Text;
            emp.EMP_FNAME = txtFname.Text;
            emp.EMP_MNAME = cmbMname.Text;
            emp.EMP_LNAME = txtLname.Text;
            emp.EMP_GENDER = cmbGender.Text;
            emp.EMP_STATUS = cmbStatus.Text;
            emp.EMP_ADDRESS = txtAddress.Text;
            emp.EMP_DEPT = txtDepartment.Text;
            emp.EMP_POSITION = txtPosition.Text;
            emp.EMP_WORKSTAT = cmbWorkStat.Text;
            emp.EMP_BASICRATE = decimal.Parse(txtRate.Text);
            emp.EMP_DATEEMPLOYED = DateTime.Parse(dtEmployed.Value.ToString());

            var img = cls.imageToByte(picAvatar.Image);
            emp.EMP_PHOTO = img;



            clsEmp.Update(emp);
            btnUpdate.Enabled = false;
            btnUpload.Enabled = false;

            txtID.Enabled = true;
            MessageBox.Show("Successfuly Updated Employee Number:" + "\n" + txtID.Text);  
            
            Clear();
            dgNo.DataSource = clsEmp.SearchNo(txtID.Text);
            timer1.Start();
        }
        //NEWNEWNEWNEWNEWNWENWENWENWEWNEWewewe
        public void Clear()
        {
            txtID.Text = "";
            txtFname.Text = "";
            cmbMname.Text = "";
            txtLname.Text = "";
            cmbGender.Text = "";
            cmbStatus.Text = "";
            txtAddress.Text = "";
            txtDepartment.Text = "";
            txtPosition.Text = "";
            cmbWorkStat.Text = "";
            txtRate.Text = "0.00";
            dtEmployed.Value = DateTime.Today;
            picAvatar.Image = Properties.Resources.no_profile;
            txtID.Enabled = true;

            dgNo.DataSource = false;

            txtID.Focus();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();

        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            string Location = "";

            OpenFileDialog pic = new OpenFileDialog();
            pic.Filter = "JPG (*.jpg)|*.jpg|GIF (*.gif)|*.gif|PNG (*.png)|*.png";
            pic.Title = "Select Image";
            if (pic.ShowDialog() == DialogResult.OK)
            {
                Location = pic.FileName.ToString();
                picAvatar.ImageLocation = Location;
            }
        }
        //NEWNEWNEWNEWNEWNWENWENWENWEWNEWewewe

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            Clear();
        }

        private void frmEmpUpdate_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmAdminMenu am = new frmAdminMenu();

            this.Hide();
            am.Show();
        }
        //NEWNEWNEWNEWNEWNWENWENWENWEWNEWewewe
    }
}
